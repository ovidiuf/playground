package com.feodorov.au.controller;

import com.feodorov.au.AssetNotFoundException;
import com.feodorov.au.InvalidAssetStateException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class ExceptionAdvice {

    @ResponseBody
    @ExceptionHandler(AssetNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    String assetNotFoundExceptionHandler(AssetNotFoundException e) {
        return "no such asset: " + e.getMessage();
    }

    @ResponseBody
    @ExceptionHandler(InvalidAssetStateException.class)
    @ResponseStatus(HttpStatus.NOT_ACCEPTABLE)
    String invalidAssetStateExceptionHandler(RuntimeException e) {
        return "not yet uploaded: " + e.getMessage();
    }

    @ResponseBody
    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    String runtimeExceptionHandler(RuntimeException e) {
        return e.getMessage();
    }


}
