package com.feodorov.au.controller;

import com.amazonaws.HttpMethod;
import com.feodorov.au.AssetNotFoundException;
import com.feodorov.au.AssetRepository;
import com.feodorov.au.InvalidAssetStateException;
import com.feodorov.au.S3Manager;
import com.feodorov.au.model.Asset;
import com.feodorov.au.model.AssetResult;
import com.feodorov.au.model.AssetStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class AssetController {

    public static final int DEFAULT_POST_EXPIRATION_TIME_SECS = 3600;
    public static final int DEFAULT_GET_EXPIRATION_TIME_SECS = 60;
    private final AssetRepository repository;
    private final S3Manager s3Manager;

    AssetController(AssetRepository assetRepository, S3Manager s3Manager ) {
        this.repository = assetRepository;
        this.s3Manager = s3Manager;
    }

    /**
     * Register an asset with the Asset Uploader Service. Upon registration, the asset has a NEW status, until the
     * client notifies the service that the asset has been uploaded.
     *
     * @return an Asset instance containing the internally-generated unique asset ID and the signed S3 URL for upload
     *
     * @exception IllegalArgumentException on missing mandatory state (bucket name, object key)
     */
    // TODO 01 What happens if we provide the same bucket name and object key?
    @PostMapping("/assets")
    AssetResult register(@RequestBody Asset asset) {
        if (asset.getBucketName() == null) {
            throw new IllegalArgumentException("missing bucket name");
        }
        if (asset.getObjectKey() == null) {
            throw new IllegalArgumentException("missing object key");
        }
        // TODO 02 More refinements on S3 backend error conditions
        String url = s3Manager.generatePresignedUrl(
                asset.getBucketName(), asset.getObjectKey(), HttpMethod.POST, DEFAULT_POST_EXPIRATION_TIME_SECS);
        asset.setId(null);
        asset.setStatus(AssetStatus.NEW);
        asset = repository.save(asset);
        return new AssetResult(asset.getId(), url);
    }

    /**
     * Mark an asset as uploaded. Upon invocation, the asset has an UPLOADED status. Successful 200 means positive
     * acknowledgment.
     *
     * @exception AssetNotFoundException on unknown ID, will be translated to 404 by the appropriate advice
     */
    // TODO 02 More refinements on S3 backend error conditions
    @PutMapping("/assets")
    void uploaded(@RequestBody Asset asset) {
        Long id = asset.getId();
        if (id == null) {
            // will be converted by controller advice to 400 Bad Request
            throw new RuntimeException("missing asset id");
        }
        asset = repository.findById(id).orElseThrow(() -> new AssetNotFoundException(Long.toString(id)));
        asset.setStatus(AssetStatus.UPLOADED);
        repository.save(asset);
    }

    /**
     * Return the download presigned URL, with an optional timeout.
     *
     * @exception AssetNotFoundException on unknown ID, will be translated to 404 by the appropriate advice
     * @exception InvalidAssetStateException then the asset exists, but it was not marked as uploaded yet.
     */
    @GetMapping("/assets/url/{id}")
    AssetResult getDownloadUrl(@PathVariable Long id, @RequestBody Integer timeoutSecs) {
        Asset asset = repository.findById(id)
                .orElseThrow(() -> new AssetNotFoundException(Long.toString(id)));

        if (AssetStatus.NEW.equals(asset.getStatus())) {
            throw new InvalidAssetStateException(asset.getId().toString());
        }

        if (timeoutSecs == null || timeoutSecs == 0) {
            timeoutSecs = DEFAULT_GET_EXPIRATION_TIME_SECS;
        }
        String url = s3Manager.generatePresignedUrl(
                asset.getBucketName(), asset.getObjectKey(), HttpMethod.GET, timeoutSecs);
        return new AssetResult(asset.getId(), url);
    }

    @GetMapping("/assets/{id}")
    Asset getAsset(@PathVariable Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new AssetNotFoundException(Long.toString(id)));
    }

    @GetMapping("/assets")
    List<Asset> all() {
        return repository.findAll();
    }
}
