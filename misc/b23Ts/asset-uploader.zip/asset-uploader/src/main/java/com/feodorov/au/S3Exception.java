package com.feodorov.au;

public class S3Exception extends RuntimeException {

    public S3Exception(String s) {
        super(s);
    }
}
