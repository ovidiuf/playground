package com.feodorov.au;

public class AssetNotFoundException extends RuntimeException {

    public AssetNotFoundException(String s) {
        super(s);
    }
}
