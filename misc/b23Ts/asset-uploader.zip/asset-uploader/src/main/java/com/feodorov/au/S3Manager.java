package com.feodorov.au;

import com.amazonaws.HttpMethod;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import org.springframework.stereotype.Component;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;

import java.net.URL;
import java.time.Instant;
import java.util.Date;

@Component
public class S3Manager {

    private AmazonS3 client;

    public static final int DEFAULT_EXPIRATION_TIME_SECS = 60;

    public S3Manager() {
        setClient(s3Client(Regions.DEFAULT_REGION));
    }

    /**
     * @param expirationTimeSecs the time interval in seconds after which the URL expires, starting with the moment
     *                          it was created. null means use the default DEFAULT_EXPIRATION_TIME_SECS.
     *
     * @exception IllegalArgumentException on invalid arguments.
     * @exception S3Exception on any interaction trouble with the backend.
     */
    public String generatePresignedUrl(
            String bucketName, String objectKey, HttpMethod httpMethod, Integer expirationTimeSecs) {
        // TODO 03 handle invalid bucket name and object key
        if (bucketName == null) {
            throw new IllegalArgumentException("null bucket name");
        }
        if (objectKey == null) {
            throw new IllegalArgumentException("null object key");
        }
        if (httpMethod == null) {
            throw new IllegalArgumentException("null HTTP method");
        }
        if (expirationTimeSecs == null) {
            expirationTimeSecs = DEFAULT_EXPIRATION_TIME_SECS;
        }
        Date expiration = computeExpirationDate(expirationTimeSecs);
        try {
            URL url = client.generatePresignedUrl(bucketName, objectKey, expiration, httpMethod);
            return url.toString();
        }
        catch (SdkClientException e) {
            // TODO 02 More refinements on S3 backend error conditions. Differentiate between AmazonServiceException
            //      (the call was transmitted successfully, but Amazon S3 couldn't process it so it returned an error
            //      response) and SdkClientException (Amazon S3 couldn't be contacted for a response, or the client
            //      couldn't parse the response from Amazon S3).
            throw new RuntimeException(e);
        }
    }

    /**
     * Protected for testing. Allows replacing the real client with a mock in testing.
     */
    void setClient(AmazonS3 client) {
        this.client = client;
    }

    @SuppressWarnings("SameParameterValue")
    private AmazonS3 s3Client(Regions clientRegion) {
        return AmazonS3ClientBuilder.standard()
                .withRegion(clientRegion)
                .withCredentials(new ProfileCredentialsProvider())
                .build();
    }

    private Date computeExpirationDate(long expirationSecs) {
        long expirationIntervalMillis = Instant.now().toEpochMilli() + expirationSecs * 1000L;
        Date expiration = new Date();
        expiration.setTime(expirationIntervalMillis);
        return expiration;
    }
}
