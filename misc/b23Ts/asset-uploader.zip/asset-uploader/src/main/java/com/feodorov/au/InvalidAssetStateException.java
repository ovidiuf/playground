package com.feodorov.au;

/**
 * Thrown by the controller when an asset was registered, but not yet uploaded, and a request for a download URL comes.
 */
public class InvalidAssetStateException extends RuntimeException {

    public InvalidAssetStateException(String s) {
        super(s);
    }
}
