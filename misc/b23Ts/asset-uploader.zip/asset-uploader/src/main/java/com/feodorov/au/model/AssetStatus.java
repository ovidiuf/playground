package com.feodorov.au.model;

public enum AssetStatus {
    /**
     * The client announced its intention to upload an asset, but no upload confirmation has been submitted yet.
     * An asset ID and an S3 URL exist at this stage.
     */
    NEW,
    /**
     * The client confirmed that the asset was uploaded in S3.
     */
    UPLOADED
}
