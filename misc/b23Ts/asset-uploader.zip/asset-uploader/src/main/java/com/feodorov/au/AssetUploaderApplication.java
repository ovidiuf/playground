package com.feodorov.au;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssetUploaderApplication {
    public static void main(String[] args) {
        SpringApplication.run(AssetUploaderApplication.class, args);
    }
}
