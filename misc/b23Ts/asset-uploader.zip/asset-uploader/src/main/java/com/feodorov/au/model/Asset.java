package com.feodorov.au.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Objects;

@SuppressWarnings("unused")
@Entity
public class Asset {

    /**
     * Internally-generated unique asset ID. Will be used to request the signed S3 URL to download the asset
     * from.
     */
    @Id
    @GeneratedValue
    private Long id;

    private String bucketName;

    private String objectKey;

    /**
     * @see AssetStatus
     */
    private AssetStatus status;

    /**
     * Optional asset description, provided by the client when expressing the intention to upload an asset.
     */
    private String description;

    public Asset() {
        this(null);
    }

    public Asset(Long id) {
        this.id = id;
    }

    /**
     * @param description null is acceptable
     */
    public Asset(String bucketName, String objectKey, String description) {
        if (bucketName == null) {
            throw new IllegalArgumentException("null bucket name");
        }
        if (objectKey == null) {
            throw new IllegalArgumentException("null object key");
        }
        this.bucketName = bucketName;
        this.objectKey = objectKey;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    public String getObjectKey() {
        return objectKey;
    }

    public void setObjectKey(String objectKey) {
        this.objectKey = objectKey;
    }

    public AssetStatus getStatus() {
        return status;
    }

    public void setStatus(AssetStatus status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    // TODO 01 What happens if we provide the same bucket name and object key?
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Asset)) {
            return false;
        }
        Asset that = (Asset)o;
        return Objects.equals(this.id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    @Override
    public String toString() {
        return "[" + id + ", " + bucketName + ":" + objectKey + ", " + status + "]";
    }
}
