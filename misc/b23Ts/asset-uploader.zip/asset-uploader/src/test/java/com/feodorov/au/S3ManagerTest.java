package com.feodorov.au;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.net.URL;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
public class S3ManagerTest {

    @Autowired
    private S3Manager s3Manager;

    private AutoCloseable mocks;

    @Mock
    private AmazonS3 mockAmazonS3;

    @BeforeEach
    public void openMocks() {
        mocks = MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    public void releaseMocks() throws Exception {
        mocks.close();
    }

    @Test
    public void generatePresignedUrl_NullBucketName() {
        try {
            s3Manager.generatePresignedUrl(null, "test-object-key", HttpMethod.POST, 1);
            fail("should have thrown exception");
        }
        catch(IllegalArgumentException e) {
            assertEquals("null bucket name", e.getMessage());
        }
    }

    @Test
    public void generatePresignedUrl_NullObjectKey() {
        try {
            s3Manager.generatePresignedUrl("test-bucket-name", null, HttpMethod.POST, 1);
            fail("should have thrown exception");
        }
        catch(IllegalArgumentException e) {
            assertEquals("null object key", e.getMessage());
        }
    }

    @Test
    public void generatePresignedUrl_NullHttpMethod() {
        try {
            s3Manager.generatePresignedUrl("test-bucket-name", "test-object-key", null, 1);
            fail("should have thrown exception");
        }
        catch(IllegalArgumentException e) {
            assertEquals("null HTTP method", e.getMessage());
        }
    }

    @Test
    public void generatePresignedUrl() throws Exception {
        s3Manager.setClient(mockAmazonS3);
        when(mockAmazonS3.generatePresignedUrl(anyString(), any(), any(), any())).thenReturn(new URL("https", "test-url", "/"));
        String s = s3Manager.generatePresignedUrl("test-bucket-name", "test-object-key", HttpMethod.POST, 1);
        assertEquals("https://test-url/", s);
    }

}
