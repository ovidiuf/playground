package com.feodorov.au;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetUploaderApplicationTests {
    @Test
    void contextLoads() {
    }
}
