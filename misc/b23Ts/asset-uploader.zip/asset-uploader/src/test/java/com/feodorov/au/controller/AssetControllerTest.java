package com.feodorov.au.controller;

import com.amazonaws.HttpMethod;
import com.feodorov.au.AssetNotFoundException;
import com.feodorov.au.AssetRepository;
import com.feodorov.au.InvalidAssetStateException;
import com.feodorov.au.S3Manager;
import com.feodorov.au.model.Asset;
import com.feodorov.au.model.AssetResult;
import com.feodorov.au.model.AssetStatus;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.List;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@SpringBootTest
public class AssetControllerTest {

    @SuppressWarnings("unused")
    @MockBean
    private S3Manager s3Manager;

    @Autowired
    private AssetController assetController;

    @Autowired
    private AssetRepository repository;

    @Test
    public void register_MissingBucketName() {
        Asset asset = new Asset();
        asset.setObjectKey("test-object-key");
        try {
            assetController.register(asset);
            fail("should have thrown exception");
        }
        catch(IllegalArgumentException e) {
            assertEquals("missing bucket name", e.getMessage());
        }
    }

    @Test
    public void register_MissingObjectKey() {
        Asset asset = new Asset();
        asset.setBucketName("test-bucket-name");
        try {
            assetController.register(asset);
            fail("should have thrown exception");
        }
        catch(IllegalArgumentException e) {
            assertEquals("missing object key", e.getMessage());
        }
    }

    @Test
    public void register() {
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), any(), anyInt())).thenReturn("s3://mock1");
        Asset asset = new Asset("test-bucket", "test-object-key", "test description");
        AssetResult result = assetController.register(asset);
        Long id = result.getId();
        assertNotNull(id);
        assertEquals("s3://mock1", result.getUrl());

        asset = assetController.getAsset(id);
        assertEquals(AssetStatus.NEW, asset.getStatus());
        assertEquals(id, asset.getId());
        assertEquals("test-bucket", asset.getBucketName());
        assertEquals("test-object-key", asset.getObjectKey());
        assertEquals("test description", asset.getDescription());
    }

    @Test
    public void uploaded_NullId() {
        Asset asset = new Asset();
        try {
            assetController.uploaded(asset);
            fail("should have thrown exception");
        }
        catch(RuntimeException e) {
            assertEquals("missing asset id", e.getMessage());
        }
    }

    @Test
    public void uploaded_AssetNotFound() {
        Asset asset = new Asset();
        asset.setId(1055L);
        try {
            assetController.uploaded(asset);
            fail("should have thrown exception");
        }
        catch(AssetNotFoundException e) {
            assertEquals("1055", e.getMessage());
        }
    }

    @Test
    public void uploaded() {
        Asset asset = new Asset("test-bucket", "test-object-key", "test description");
        AssetResult result = assetController.register(asset);
        Long id = result.getId();
        assetController.uploaded(new Asset(id));
        assertEquals(AssetStatus.UPLOADED, assetController.getAsset(id).getStatus());
    }

    @Test
    public void getDownloadedUrl_AssetNotFound() {
        try {
            assetController.getDownloadUrl(2023L, null);
            fail("should have thrown exception");
        }
        catch(AssetNotFoundException e) {
            assertEquals("2023", e.getMessage());
        }
    }

    @Test
    public void getDownloadedUrl_BeforeAssetIsUploaded() {
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), eq(HttpMethod.POST), anyInt()))
                .thenReturn("s3://mock2");
        Asset asset = new Asset("test-bucket", "test-object-key", "test description");
        AssetResult result = assetController.register(asset);
        Long id = result.getId();
        // the asset has not been marked as "uploaded" yet
        try {
            assetController.getDownloadUrl(id, 10);
            fail("should have thrown exception");
        }
        catch(InvalidAssetStateException e) {
            assertEquals(Long.toString(id), e.getMessage());
        }
    }

    @Test
    public void getDownloadedUrl_WithExplicitTimeout() {
        int explicitTimeout = 1343;
        assertNotEquals(explicitTimeout, AssetController.DEFAULT_GET_EXPIRATION_TIME_SECS);
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), eq(HttpMethod.POST), anyInt()))
                .thenReturn("s3://mock3");
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), eq(HttpMethod.GET), eq(AssetController.DEFAULT_GET_EXPIRATION_TIME_SECS)))
                .thenReturn("s3://mock4");
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), eq(HttpMethod.GET), eq(explicitTimeout)))
                .thenReturn("s3://mock5");
        Asset asset = new Asset("test-bucket", "test-object-key", "test description");
        AssetResult result = assetController.register(asset);
        Long id = result.getId();
        assetController.uploaded(new Asset(id));
        result = assetController.getDownloadUrl(id, explicitTimeout);
        assertEquals("s3://mock5", result.getUrl());
    }

    @Test
    public void getDownloadedUrl_WithDefaultTimeout_MissingTimeout() {
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), eq(HttpMethod.POST), anyInt()))
                .thenReturn("s3://mock6");
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), eq(HttpMethod.GET), eq(AssetController.DEFAULT_GET_EXPIRATION_TIME_SECS)))
                .thenReturn("s3://mock7");
        Asset asset = new Asset("test-bucket", "test-object-key", "test description");
        AssetResult result = assetController.register(asset);
        Long id = result.getId();
        assetController.uploaded(new Asset(id));
        result = assetController.getDownloadUrl(id, null);
        assertEquals("s3://mock7", result.getUrl());
    }

    @Test
    public void getDownloadedUrl_WithDefaultTimeout_ZeroTimeout() {
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), eq(HttpMethod.POST), anyInt()))
                .thenReturn("s3://mock8");
        when(s3Manager.generatePresignedUrl(anyString(), anyString(), eq(HttpMethod.GET), eq(AssetController.DEFAULT_GET_EXPIRATION_TIME_SECS)))
                .thenReturn("s3://mock9");
        Asset asset = new Asset("test-bucket", "test-object-key", "test description");
        AssetResult result = assetController.register(asset);
        Long id = result.getId();
        assetController.uploaded(new Asset(id));
        result = assetController.getDownloadUrl(id, 0);
        assertEquals("s3://mock9", result.getUrl());
    }

    @Test
    public void get_AssetNotFound() {
        try {
            assetController.getAsset(2022L);
            fail("should have thrown exception");
        }
        catch(AssetNotFoundException e) {
            assertEquals("2022", e.getMessage());
        }
    }

    @Test
    public void get() {
        Asset asset = new Asset("test-bucket", "test-object-key", "test description");
        AssetResult result = assetController.register(asset);
        Long id = result.getId();
        asset = assetController.getAsset(id);
        assertEquals(AssetStatus.NEW, asset.getStatus());
        assertEquals("test-bucket", asset.getBucketName());
        assertEquals("test-object-key", asset.getObjectKey());
        assertEquals("test description", asset.getDescription());
    }

    @Test
    public void all() {
        repository.deleteAll();
        List<Asset> assets = assetController.all();
        assertTrue(assets.isEmpty());
        Asset asset = new Asset("test-bucket", "test-object-key", "test description");
        AssetResult result = assetController.register(asset);
        Long id = result.getId();
        assets = assetController.all();
        assertEquals(1, assets.size());
        assertEquals(id, assets.get(0).getId());
        assertEquals("test-bucket", assets.get(0).getBucketName());
        assertEquals("test-object-key", assets.get(0).getObjectKey());
        assertEquals("test description", assets.get(0).getDescription());
    }
}
