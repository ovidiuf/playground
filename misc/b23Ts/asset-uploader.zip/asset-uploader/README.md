# Asset Uploader 

Ovidiu Feodorov 10/03/2021

## Overview

This project is the implementation of a service that allows a user to upload an asset and then request a time expiring URL to retrieve the asset. The implementation closely follows the specification provided as https://app.codility.com/test/2N2EBW-9QJ/. 

### Potential Loss of State Warning

⚠️ To avoid complications related to installing a real database, the project uses H2, which is an in-memory database. This makes the project self-contained and really convenient to build and run as a service, but the state is lost if the server goes down. The solution is simply replacing H2 with a production-quality database and swapping the dependencies in the classpath. 

## Solution Architecture

The Asset Uploader is implemented as a Spring Boot application, which consists in three main components: the [AssetController](./src/main/java/com/feodorov/au/controller/AssetController.java), a Spring Boot REST Controller that provides the API functionality, a [S3Manager](./src/main/java/com/feodorov/au/S3Manager.java) component that handles interaction with the AWS S3 backend and creates various types of presigned S3 URLs, and a [JPA repository](./src/main/java/com/feodorov/au/AssetRepository.java) that persists Asset state. The components are wired into each other using dependency injection. The project was created and initialized with Spring Initializr, via the IntelliJ Spring Boot plugin, so it closely matches the structure of a canonical Spring Boot project.
## Prerequisites

* Java 11 SDK installed on the system, with `java` binary present in `PATH`. To check, run `java -version` from a terminal. You should get something similar to:
```text
openjdk version "17" 2021-09-14 LTS
OpenJDK Runtime Environment Corretto-17.0.0.35.2 (build 17+35-LTS)
OpenJDK 64-Bit Server VM Corretto-17.0.0.35.2 (build 17+35-LTS, mixed mode, sharing)
```
* `curl` preset in `PATH`. To check, run `curl --version`. You should get something similar to:
```text
curl 7.64.1 (x86_64-apple-darwin20.0) libcurl/7.64.1 (SecureTransport) [...]
```
* Valid AWS API credentials for programmatic access to an AWS account, in the form of an access key and a secret key. The credentials should be set up as described here: [Working with AWS Credentials](https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/credentials.html). If AWS access is not setup, the asset registration and attempts to get a download URL will fail.
* An existing S3 bucket in the AWS account credentials are available for.

## Build

Unzip the project ZIP `asset-uploader.zip` in a work directory. An `asset-uploader` subdirectory will be created. From that directory, execute:

```shell
cd ./asset-uploader
./gradlew build
```
The build must be successful to proceed further:

```text
./gradlew  build

> Task :test
[...]

BUILD SUCCESSFUL in 6s
7 actionable tasks: 7 executed
```
Note that the Java 11 `java` binary should be present in the `PATH`, as per the [Prerequisites](#prerequisites) section. Gradle does not need to be installed on the system, it will bootstrap itself.

The build process compiles the code, executes the [automated tests](#automated-testing) and creates the application JAR as `build/libs/asset-uploader-0.1.0.jar`.

### Automated Testing

The build sequence will automatically run all the unit test. We are using Spring Boot Mockito support to mock various components (for example [com.feodorov.au.S3Manager](./src/main/java/com/feodorov/au/S3Manager.java)) and test other components ([com.feodorov.au.controller.AssetController](./src/main/java/com/feodorov/au/controller/AssetController.java)) with the mock test doubles. Once the tests are executed, the unit test report is available as [./build/reports/tests/test/index.html](./build/reports/tests/test/index.html). All tests must pass:

![Test Report](./doc/test-report.png)

## Manual Testing

A set of convenience scripts are provided in the `bin` directory. Their usage is described below.

### Start the Server

After building the server as described in the [Build](#build) section, start the server locally using the provided start script `./bin/run`

```shell
./bin/run
```

You should see something similar to:

```shell

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/
 :: Spring Boot ::                (v2.5.5)

2021-10-03 15:01:13.576  INFO 8326 --- [           main] c.feodorov.au.AssetUploaderApplication   : Starting AssetUploaderApplication using Java 17 on NOMBP4.novaordis.com with PID 8326 (/Users/ovidiu/projects/datastax-codility/asset-uploader/build/libs/asset-uploader-0.1.0.jar started by ovidiu in /Users/ovidiu/projects/datastax-codility/asset-uploader)
[...]
2021-10-03 15:01:16.816  [...] Started AssetUploaderApplication in 3.679 seconds (JVM running for 4.086)
```

### Register an Asset

While leaving the server running, start a new terminal and go the `asset-uploader` directory. To register an asset, use:

```shell
./bin/register <bucket-name> <object-key> [description]
```

The bucket name and the object key are required, the asset description is optional.

Example:

```shell
./bin/register novaordis kitten "picture of a kitten"
```

The invocation is sent with `curl` and the response is rendered within `curl` output. Note that `curl` is executed in verbose mode, so other request/response state information is rendered as well:

```text
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 8080 (#0)
> POST /assets HTTP/1.1
> Host: localhost:8080
> User-Agent: curl/7.64.1
> Accept: */*
> Content-Type: application/json
> Content-Length: 85
>
* upload completely sent off: 85 out of 85 bytes
< HTTP/1.1 200
< Content-Type: application/json
< Transfer-Encoding: chunked
< Date: Sun, 03 Oct 2021 22:04:25 GMT
<
* Connection #0 to host localhost left intact
{"id":1,"url":"https://novaordis.s3.us-west-2.amazonaws.com/kitten?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20211003T220425Z&X-Amz-SignedHeaders=host&X-Amz-Expires=3599&X-Amz-Credential=AKIA3VMSGMKJZEJ2U4TU%2F20211003%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Signature=6f3fd1407ac7d8fa057f03716202cfed765b75ac259f11f962648eca0e3a2e94"}
* Closing connection 0
```

The result contains a JSON document that provides the ID of the asset (as `"id"`) and the upload URL (as `"url"`), as specified in the project requirements. All persisted assets can be displayed at any time with:

```text
./bin/assets
```

### Attempt to Get the Download URL Before Upload

Before marking an asset as "uploaded", execute the following command. Note that the ID of the existing assets and their status can be obtained at any moment with `./bin/assets`.

```bash
./bin/get <asset-id> 
```

Example:

```bash
./bin/get 1 
```

The server responds with a 406 Not Acceptable, because the asset has not yet been marked as "uploaded":

```text
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 8080 (#0)
> GET /assets/url/1 HTTP/1.1
> Host: localhost:8080
> User-Agent: curl/7.64.1
> Accept: */*
> Content-Type: application/json
> Content-Length: 1
>
* upload completely sent off: 1 out of 1 bytes
  < HTTP/1.1 406
  < Content-Type: text/plain;charset=UTF-8
  < Content-Length: 19
  < Date: Sun, 03 Oct 2021 22:22:26 GMT
  <
* Connection #0 to host localhost left intact
  not yet uploaded: 1
* Closing connection 0
```

### Mark The Asset as Uploaded

Upload the asset to the S3 backend using the presigned URL generated during step [Register an Asset](#register-an-asset).

⚠️ The actual upload to S3 is not handled by this implementation, because the requirements do not seem to specifically request it. More details on how to actually upload and download objects in S3 with presigned URL are available here: [Uploading objects using presigned URLs](https://docs.aws.amazon.com/AmazonS3/latest/userguide/PresignedUrlUploadObject.html) and [Sharing an object with a presigned URL](https://docs.aws.amazon.com/AmazonS3/latest/userguide/ShareObjectPreSignedURL.html). Providing tooling to do the upload and download can be considered as "Further Work", as mentioned in the [TODO 04](#todo-04) section below.

Using the asset ID, mark it as "uploaded":

```shell
./bin/uploaded <asset-id>
```
Example:

```shell
./bin/uploaded 1
```

Note the 200 response that is the only confirmation that the operation completed successfully:

```text
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 8080 (#0)
> PUT /assets HTTP/1.1
> Host: localhost:8080
> User-Agent: curl/7.64.1
> Accept: */*
> Content-Type: application/json
> Content-Length: 10
>
* upload completely sent off: 10 out of 10 bytes
< HTTP/1.1 200
< Content-Length: 0
< Date: Sun, 03 Oct 2021 22:35:40 GMT
<
* Connection #0 to host localhost left intact
* Closing connection 0
```
The download URL can be generated now, as described in the following step [Obtain the Download URL](#obtain-the-download-url):

### Obtain the Download URL

The download URL can be generated using an explicit timeout in seconds or using the default timeout, if none is specified in the request.

#### Download URL with Explicit Timeout

```shell
./bin/get <asset-id> <timeout-secs>
```
Example:

```shell
./bin/get 1 3600
```

```text
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 8080 (#0)
> GET /assets/url/1 HTTP/1.1
> Host: localhost:8080
> User-Agent: curl/7.64.1
> Accept: */*
> Content-Type: application/json
> Content-Length: 4
>
* upload completely sent off: 4 out of 4 bytes
< HTTP/1.1 200
< Content-Type: application/json
< Transfer-Encoding: chunked
< Date: Sun, 03 Oct 2021 22:39:05 GMT
<
* Connection #0 to host localhost left intact
{"id":1,"url":"https://novaordis.s3.us-west-2.amazonaws.com/kitten?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20211003T223905Z&X-Amz-SignedHeaders=host&X-Amz-Expires=3600&X-Amz-Credential=AKIA3VMSGMKJZEJ2U4TU%2F20211003%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Signature=5d3a44fcb1134054edbb231f6b02711dc8a0904c8ca74ebd868eece0ec417c89"}
* Closing connection 0
```

#### Download URL with Default Timeout

```shell
./bin/get <asset-id>
```
Example:

```shell
./bin/get 1
```

```text
NOMBP4:asset-uploader ovidiu$ ./bin/get 1
[warn]: no timeout (in secs) has been provided, but that's OK, the default will be used
*   Trying ::1...
* TCP_NODELAY set
* Connected to localhost (::1) port 8080 (#0)
> GET /assets/url/1 HTTP/1.1
> Host: localhost:8080
> User-Agent: curl/7.64.1
> Accept: */*
> Content-Type: application/json
> Content-Length: 1
>
* upload completely sent off: 1 out of 1 bytes
< HTTP/1.1 200
< Content-Type: application/json
< Transfer-Encoding: chunked
< Date: Sun, 03 Oct 2021 22:43:32 GMT
<
* Connection #0 to host localhost left intact
{"id":1,"url":"https://novaordis.s3.us-west-2.amazonaws.com/kitten?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Date=20211003T224332Z&X-Amz-SignedHeaders=host&X-Amz-Expires=59&X-Amz-Credential=AKIA3VMSGMKJZEJ2U4TU%2F20211003%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Signature=955dc1b7212037908cb27fc4dc3b93d4b303b6af970cb27f1db6bdf06d24a140"}
* Closing connection 0
```

## Further Work

The following situations require further attention, and they would be addressed in case of a production-quality implementation:

### TODO 01
What happens if the same bucket/object key is registered twice. The current implementation will simply duplicate the asset information, which is not correct. A correct implementation will require a composite primary key or at least taking this situation into account when the unique ID is computed. Search for "TODO 01" in code.
### TODO 02
We are simply bubbling up S3 backend error conditions as RuntimeExceptions and the service will respond with 400 in those situations. This requires further refinement. Search for "TODO 02" in code.
### TODO 03
Some bucket names and object keys are bound to be invalid, due to S3 limitations. Currently we're not handling these situations and we're relying on the back end to fail. Further refinement could be used here. Search for "TODO 03" in code.
### TODO 04
Provide tooling to actually upload and download. We are not currently doing anything with the presigned URLs.